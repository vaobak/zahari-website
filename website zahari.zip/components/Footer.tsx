export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-800">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between space-y-4 md:flex-row md:space-y-0">
          <div className="flex flex-col items-center space-y-2 md:items-start">
            <h3 className="text-lg font-semibold text-white">Dr. Zahari, S.Kom.I, M.Kom.I</h3>
            <p className="text-sm text-gray-300">Dosen & Peneliti di bidang Ilmu Komputer</p>
          </div>
          
          <div className="flex flex-col items-center space-y-2 md:items-end">
            <p className="text-sm text-gray-300">
              © {currentYear} Dr. Zahari. All rights reserved.
            </p>
            <p className="text-xs text-gray-400">
              Website dibuat dengan Next.js & Tailwind CSS
            </p>
          </div>
        </div>
        
        <div className="mt-6 border-t border-gray-700 pt-6">
          <div className="flex flex-wrap justify-center space-x-6 text-sm text-gray-300">
            <span>Email: zahari@university.ac.id</span>
            <span>•</span>
            <span>Universitas XYZ</span>
            <span>•</span>
            <span>Fakultas Ilmu Komputer</span>
          </div>
        </div>
      </div>
    </footer>
  )
}